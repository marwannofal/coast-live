// SPDX-License-Identifier: GPL-2.0-or-later
import Cairo from 'cairo';
import Gio from 'gi://Gio';
import { worldFor } from './world-catalog.js';
import { paintWorldArt, paintSkyPlate } from './world-art.js';
import { paintWorldMotion, paintWorldSky } from './world-motion.js';
import Clutter from 'gi://Clutter';
import Cogl from 'gi://Cogl';
import GdkPixbuf from 'gi://GdkPixbuf';
import GLib from 'gi://GLib';
import St from 'gi://St';

import { Extension } from 'resource:///org/gnome/shell/extensions/extension.js';
import * as Main from 'resource:///org/gnome/shell/ui/main.js';

import { BackgroundSync } from './background-sync.js';
import { effectiveTime } from './display-clock.js';
import { paintBirds, paintDuneSand, paintFireflies, paintFoam, paintRockShadows } from './scene-details.js';
import { CELESTIAL_HEIGHT, celestialState, paintCelestial, skyPalette } from './celestial.js';
import { DESERT_FX_TOP, paintDesert, palmAngle } from './desert.js';
import { LocalLocation } from './location.js';
import { LunarPhaseTable } from './lunar.js';
import { paintAtmosphere } from './weather.js';
import { describeWeather, WeatherFeed } from './weather-feed.js';
import { WeatherHttp } from './weather-http.js';
import { SOLAR_ART_FRAMES, solarPhase, solarSchedule } from './solar-clock.js';
import {
    CLOUDS, EXTRA_CLOUDS, HEIGHT, WATER_TOP, WIDTH, cloudPosition, paintCloud, paintGrass, paintWater,
} from './scene.js';

const ANIMATION_INTERVAL_MS = { economy: 125, balanced: 67, smooth: 40, ultra: 20 };
const SOLAR_INTERVAL = 1_000_000;
const LOCATION_INTERVAL = 3_000_000;
const CLOUD_TINT_INTERVAL = 0.8;

function cairoPainter(cr) {
    return {
        color: (rgb, alpha) => cr.setSourceRGBA(rgb[0] / 255, rgb[1] / 255, rgb[2] / 255, alpha),
        rectangle: (x, y, width, height) => cr.rectangle(x, y, width, height),
        fill: () => cr.fill(),
        save: () => cr.save(),
        restore: () => cr.restore(),
        moveTo: (x, y) => cr.moveTo(x, y),
        lineTo: (x, y) => cr.lineTo(x, y),
        close: () => cr.closePath(),
        clip: () => cr.clip(),
        lineWidth: width => cr.setLineWidth(width),
        curveTo: (...points) => cr.curveTo(...points),
        circle: (x,y,radius) => { cr.newSubPath(); cr.arc(x,y,radius,0,2*Math.PI); },
        stroke: () => cr.stroke(),
    };
}

function drawingArea(width, height, paint, antialias = Cairo.Antialias.NONE) {
    const area = new St.DrawingArea({ width, height, reactive: false });
    area.connect('repaint', () => {
        const cr = area.get_context();
        try {
            cr.setOperator(Cairo.Operator.CLEAR);
            cr.paint();
            cr.setOperator(Cairo.Operator.OVER);
            cr.setAntialias(antialias);
            paint(cairoPainter(cr), cr);
        } finally {
            cr.$dispose();
        }
    });
    return area;
}

export default class CoastLive extends Extension {
    enable() {
        this._group = Main.layoutManager._backgroundGroup;
        if (!this._group)
            throw new Error('Coast Live could not locate the desktop background group.');

        try {
            const [ok, bytes] = this.dir.get_child('scene-data.json').load_contents(null);
            if (!ok)
                throw new Error('Coast Live could not load scene data.');
            this._data = JSON.parse(new TextDecoder().decode(bytes));
            if (this._data.frames.length !== SOLAR_ART_FRAMES)
                throw new Error('Coast Live expects 2,000 solar lighting frames.');

            this._views = [];
            this._skyCache = new Map();
            this._settings = this.getSettings();
            this._theme = this._settings.get_string('theme');
            this._world = worldFor(this._theme);
            const dataDir = this.dir.get_child('data');
            const [, weather] = dataDir.get_child('weather.json').load_contents(null);
            this._presets = JSON.parse(new TextDecoder().decode(weather));
            const [, lunar] = dataDir.get_child('moon-phases.bin').load_contents(null);
            this._lunarTable = new LunarPhaseTable(lunar);
            this._weather = this._presets.clear;
            const weatherHttp = new WeatherHttp();
            this._weatherFeed = new WeatherFeed(url => weatherHttp.request(url),
                state => this._settings.set_string('weather-status', describeWeather(state)),
                Date.now, () => GLib.get_monotonic_time() / 1000);
            this._settings.set_string('weather-status', '');
            this._nextWeather = 0;
            this._timePreviewActive = false;
            this._backgroundTimeChanged = false;
            const [, layout] = this.dir.get_child('themes').get_child('layout.json').load_contents(null);
            this._layout = JSON.parse(new TextDecoder().decode(layout));
            this._terrainCache = new Map();
            this._location = new LocalLocation(this.path);
            this._motionStart = GLib.get_monotonic_time();
            this._elapsed = 0;
            this._coordinates = null;
            this._schedule = null;
            this._phase = null;
            this._nextSolar = 0;
            this._nextLocation = 0;
            this._nextTint = 0;
            this._configureBackgroundSync();
            this._updateSolarFrame();
            this._buildViews();

            this._monitorSignal = Main.layoutManager.connect('monitors-changed', () => this._buildViews());
            this._backgroundSignal = this._group.connect('child-added', () => {
                for (const view of this._views)
                    this._group.set_child_above_sibling(view.root, null);
            });
            this._settingsSignals = [
                this._settings.connect('changed::animation-speed', () => this._startAnimation()),
                this._settings.connect('changed::match-gnome-background', () => this._configureBackgroundSync()),
                this._settings.connect('changed::fixed-minute', () => {
                    this._nextSolar = 0;
                    this._backgroundTimeChanged = true;
                }),
                this._settings.connect('changed::time-preview', () => { this._nextSolar = 0; }),
                this._settings.connect('changed::weather', () => {
                    if (this._settings.get_string('weather') !== 'live') {
                        this._weatherFeed.stop();
                        this._settings.set_string('weather-status', '');
                    }
                    this._nextSolar = 0;
                    this._updateSolarFrame();
                }),
                this._settings.connect('changed::theme', () => {
                    this._theme = this._settings.get_string('theme');
                    this._world = worldFor(this._theme);
                    this._terrainCache.clear();
                    this._skyCache.clear();
                    this._buildViews();
                    this._syncBackground(true);
                }),
            ];
            this._startAnimation();
        } catch (error) {
            this.disable();
            throw error;
        }
    }

    _startAnimation() {
        if (this._tickId)
            GLib.Source.remove(this._tickId);
        const mode = this._settings.get_string('animation-speed');
        this._tickId = GLib.timeout_add(GLib.PRIORITY_DEFAULT, ANIMATION_INTERVAL_MS[mode], () => {
            this._tick();
            return GLib.SOURCE_CONTINUE;
        });
    }

    _configureBackgroundSync() {
        this._backgroundSync?.restore();
        this._backgroundSync = this._settings.get_boolean('match-gnome-background')
            ? new BackgroundSync()
            : null;
        this._syncBackground();
    }

    _themeFile(name) {
        return this.dir.get_child('themes').get_child(this._theme).get_child(name);
    }

    _syncBackground(force = false) {
        if (!this._backgroundSync || this._phase === null || this._timePreviewActive)
            return;

        const file = this._worldSnapshot(force || this._backgroundTimeChanged);
        this._backgroundSync.update(file.get_uri(), GLib.get_monotonic_time(), force || this._backgroundTimeChanged);
        this._backgroundTimeChanged = false;
    }

    _worldSnapshot(force) {
        const now = GLib.get_monotonic_time();
        if (!force && this._worldPreview && this._worldPreviewTheme === this._theme &&
                now - this._worldPreviewTime < 60_000_000)
            return this._worldPreview;
        const world = this._world;
        const scale = world?.skyScale ?? (this._layout.skyScales[this._theme] ?? 1);
        const surface = world ? Cairo.ImageSurface.createFromPNG(this.path + '/worlds/' + world.id + '.png') : null;
        const target = new Cairo.ImageSurface(Cairo.Format.ARGB32, 1920, 1080);
        const cr = new Cairo.Context(target);
        try {
            cr.scale(2, 2);
            const [first, last, blend] = skyPalette(this._phase / 4);
            for (const [name, opacity] of [[first, 1], [last, blend]]) {
                if (!opacity) continue;
                const sky = Cairo.ImageSurface.createFromPNG(this.path + '/sky/' + name + '.png');
                paintSkyPlate(cr, sky, scale, opacity, this._theme === 'coast');
            }
            paintCelestial(cr, Cairo, this._phase / 4, this._celestial, this._theme !== 'coast', this._lunar, this._weather, scale);
            const paint = cairoPainter(cr);
            if (world) paintWorldSky(paint, world, this._elapsed, this._light.day / 255, this._weather);
            for (const spec of [...CLOUDS, ...EXTRA_CLOUDS].slice(0, world?.id === 'kelp' ? 0 : this._weather.clouds)) {
                const [x,y] = cloudPosition(spec, this._elapsed * this._weather.cloudSpeed);
                cr.save(); cr.translate(x,y*scale); cr.scale(spec.scale,spec.scale*scale);
                paintCloud(paint,this._data.clouds[spec.bank],spec,this._light,x,y,this._weather); cr.restore();
            }
            if (world) {
                paintWorldArt(cr, Cairo, surface, this._light.day / 255, this._light.sunlight, this._world);
                paintWorldMotion(paint, world, this._elapsed, this._light, this._weather);
            } else if (this._theme === 'coast') {
                paintBirds(paint,this._elapsed,this._light,this._weather);
                paintWater(paint,this._elapsed,this._light,this._data.coast,this._weather);
                paintFoam(paint,this._elapsed,this._light,this._data.coast,this._weather);
                paintGrass(paint,this._elapsed,this._light,this._weather);
            } else {
                const anchors = this._layout.anchors;
                const high = anchors.findIndex(n => n > this._phase);
                const lower = high < 0 ? anchors.length - 1 : Math.max(0,high-1);
                const upper = high < 0 ? lower : high;
                const ratio = lower === upper ? 0 : (this._phase - anchors[lower]) / (anchors[upper] - anchors[lower]);
                const drawLayer = (prefix, bounds) => {
                    for (const [slot, opacity] of [[lower,1],[upper,ratio]]) {
                        if (!opacity) continue;
                        const image = Cairo.ImageSurface.createFromPNG(this._themeFile(prefix + '-' + String(slot).padStart(2,'0') + '.png').get_path());
                        cr.save();cr.translate(bounds[0],bounds[1]);cr.scale(bounds[2]/image.getWidth(),bounds[3]/image.getHeight());
                        cr.setSourceSurface(image,0,0);cr.paintWithAlpha(opacity);cr.restore();
                    }
                };
                drawLayer('ground',[0,0,WIDTH,HEIGHT]);
                if(this._theme==='plateau')paintRockShadows(paint,this._light,this._weather);
                paintDesert(paint,this._elapsed,this._light,this._theme,this._weather);
                if(this._theme==='dunes')paintDuneSand(paint,this._elapsed,this._light,this._weather);
                if(this._theme==='oasis') {
                    paintFireflies(paint,this._elapsed,this._phase,this._weather);
                    for(const [i,[x1,y1,x2,y2]] of this._layout.palms.entries())drawLayer('palm-'+i,[x1,y1,x2-x1,y2-y1]);
                }
            }
            cr.save();
            if(world?.window){cr.rectangle(...world.window);cr.clip();}
            if(world?.id !== 'kelp')paintAtmosphere(paint,cr,Cairo,this._weather,this._light.day/255,this._elapsed);
            cr.restore();
            const directory = GLib.build_filenamev([GLib.get_user_cache_dir(), 'coast-live']);
            GLib.mkdir_with_parents(directory, 0o700);
            // Alternate two names so GNOME notices the changed still; bounded cache size.
            this._worldPreviewSlot = 1 - (this._worldPreviewSlot ?? 0);
            const path = GLib.build_filenamev([directory, 'world-preview-' + this._worldPreviewSlot + '.png']);
            target.writeToPNG(path);
            this._worldPreview = Gio.File.new_for_path(path);
            this._worldPreviewTheme = this._theme;
            this._worldPreviewTime = now;
            return this._worldPreview;
        } finally { cr.$dispose(); }
    }

    _loadTexture(file) {
        return this._pixbufTexture(GdkPixbuf.Pixbuf.new_from_file(file.get_path()));
    }

    _pixbufTexture(pixbuf) {
        const content = St.ImageContent.new_with_preferred_size(pixbuf.width, pixbuf.height);
        const format = pixbuf.get_has_alpha() ? Cogl.PixelFormat.RGBA_8888 : Cogl.PixelFormat.RGB_888;
        const args = [pixbuf.read_pixel_bytes(), format, pixbuf.width, pixbuf.height, pixbuf.rowstride];
        if (content.set_bytes.length === 6)
            args.unshift(global.stage.context.get_backend().get_cogl_context());
        if (!content.set_bytes(...args))
            throw new Error('Coast Live could not upload a wallpaper texture.');
        return content;
    }

    _updateSky() {
        if (!this._views.length)
            return;

        const desert = this._theme !== 'coast';
        const [first, last, weight] = skyPalette(this._phase / 4);
        const opacity = first === last ? 0 : Math.round(weight * 255);
        const names = opacity ? [first, last] : [first];
        const previous = this._skyCache;
        const next = new Map();
        const sky = this.dir.get_child('sky');
        for (const name of names) {
            if (previous.has(name)) {
                next.set(name, previous.get(name));
                continue;
            }
            const pixbuf = GdkPixbuf.Pixbuf.new_from_file(sky.get_child(name + '.png').get_path());
            if (desert) {
                const height = Math.round(pixbuf.height * WATER_TOP / HEIGHT);
                const top = pixbuf.new_subpixbuf(0, 0, pixbuf.width, height);
                const edge = pixbuf.new_subpixbuf(0, height - 1, pixbuf.width, 1);
                next.set(name, { sky: this._pixbufTexture(top), horizon: this._pixbufTexture(edge) });
            } else {
                next.set(name, { sky: this._pixbufTexture(pixbuf) });
            }
        }
        this._skyCache = next;

        for (const view of this._views) {
            view.sky[0].content = next.get(first).sky;
            view.sky[1].content = opacity ? next.get(last).sky : null;
            view.sky[1].opacity = opacity;
            if (desert) {
                view.horizon[0].content = next.get(first).horizon;
                view.horizon[1].content = opacity ? next.get(last).horizon : null;
                view.horizon[1].opacity = opacity;
            }
            view.celestial.queue_repaint();
        }
    }

    _updateTerrain() {
        if (this._theme === 'coast')
            return;

        if (this._world) {
            for (const view of this._views) view.worldArt?.queue_repaint();
            return;
        }
        const anchors = this._layout.anchors;
        const phase = Math.min(SOLAR_ART_FRAMES - 1, this._phase);
        const high = anchors.findIndex(frame => frame > phase);
        const lower = high < 0 ? anchors.length - 1 : Math.max(0, high - 1);
        const upper = high < 0 ? lower : high;
        const opacity = lower === upper ? 0 : Math.round(255 * (phase - anchors[lower]) / (anchors[upper] - anchors[lower]));
        const previous = this._terrainCache;
        const next = new Map();
        const texture = (prefix, slot) => {
            const name = prefix + '-' + String(slot).padStart(2, '0') + '.png';
            if (!next.has(name))
                next.set(name, previous.get(name) ?? this._loadTexture(this._themeFile(name)));
            return next.get(name);
        };
        const layers = (actors, prefix) => {
            actors[0].content = texture(prefix, lower);
            actors[1].content = texture(prefix, upper);
            actors[1].opacity = opacity;
        };
        for (const view of this._views) {
            layers(view.terrain, 'ground');
            for (const [i, palm] of view.palms.entries())
                layers(palm.layers, 'palm-' + i);
        }
        this._terrainCache = next;
    }

    _updateSolarFrame(monotonic = GLib.get_monotonic_time()) {
        const now = Date.now();
        const { time, previewing } = effectiveTime(now, this._settings.get_int('fixed-minute'),
            this._settings.get_string('time-preview'));
        this._timePreviewActive = previewing;
        if (!this._coordinates || monotonic >= this._nextLocation) {
            const { coordinates } = this._location.resolve(this._settings, now);
            if (!this._coordinates || coordinates.some((value, i) => value !== this._coordinates[i])) {
                this._schedule = null;
                this._coordinates = coordinates;
            }
            this._nextLocation = monotonic + LOCATION_INTERVAL;
        }

        if (!this._schedule || time < this._schedule.start || time >= this._schedule.end)
            this._schedule = solarSchedule(time, ...this._coordinates);

        const weatherMode = this._settings.get_string('weather');
        if (weatherMode === 'live')
            this._weatherFeed.update(this._coordinates);
        const weather = weatherMode === 'live' ? this._weatherFeed.state?.reading?.preset :
            this._presets[weatherMode];
        const nextWeather = weather ?? this._presets.clear;
        const weatherChanged = this._weather !== nextWeather;
        this._weather = nextWeather;
        const phase = solarPhase(time, this._schedule);
        if (!weatherChanged && phase === this._phase && time === this._lastSolarTime) {
            this._syncBackground();
            return false;
        }

        this._phase = phase;
        this._lastSolarTime = time;
        this._lunar = this._lunarTable.at(time);
        this._celestial = celestialState(phase / 4);
        const { sun, moon, sunlight } = this._celestial;
        this._light = {
            ...this._data.frames[Math.min(SOLAR_ART_FRAMES - 1, Math.floor(phase))],
            sun: [sun[0], sun[1], sun[2] * 255 * this._weather.light],
            moon: [moon[0], moon[1], moon[2] * 255 * this._lunar.illuminated * this._weather.light],
            sunlight,
        };
        if (weatherChanged && this._views.length) {
            this._buildViews();
        } else {
            this._updateSky();
            this._updateTerrain();
        }
        this._syncBackground();
        return true;
    }

    _buildViews() {
        this._destroyViews();
        const desert = this._theme !== 'coast';
        const skyScale = this._world?.skyScale ?? (desert ? this._layout.skyScales[this._theme] : 1);
        if (this._world && this._worldSurfaceId !== this._theme) {
            this._worldSurface = Cairo.ImageSurface.createFromPNG(this.path + '/worlds/' + this._theme + '.png');
            this._worldSurfaceId = this._theme;
        }
        for (const monitor of Main.layoutManager.monitors) {
            const root = new St.Widget({
                x: monitor.x, y: monitor.y, width: monitor.width, height: monitor.height,
                clip_to_allocation: true, reactive: false, layout_manager: new Clutter.FixedLayout(),
            });
            const scene = new St.Widget({
                width: WIDTH, height: HEIGHT, reactive: false, layout_manager: new Clutter.FixedLayout(),
            });
            const scale = Math.max(monitor.width / WIDTH, monitor.height / HEIGHT);
            scene.set_scale(scale, scale);
            scene.set_position((monitor.width - WIDTH * scale) / 2, (monitor.height - HEIGHT * scale) / 2);
            root.add_child(scene);

            const newLayers = (parent, width, height, y = 0) => [0, 1].map(() => {
                const actor = new St.Widget({
                    width, height, y, reactive: false,
                    content_gravity: Clutter.ContentGravity.RESIZE_FILL,
                });
                parent.add_child(actor);
                return actor;
            });
            const skyHeight = desert ? Math.round(WATER_TOP * skyScale) : HEIGHT;
            const horizon = desert ? newLayers(scene, WIDTH, HEIGHT - skyHeight, skyHeight) : [];
            const sky = newLayers(scene, WIDTH, skyHeight);
            const celestial = drawingArea(WIDTH, desert ? skyHeight : CELESTIAL_HEIGHT, (_paint, cr) => {
                paintCelestial(cr, Cairo, this._phase / 4, this._celestial, desert, this._lunar, this._weather, skyScale);
            }, Cairo.Antialias.DEFAULT);
            scene.add_child(celestial);

            const worldSky = this._world ? drawingArea(WIDTH, HEIGHT, paint => {
                paintWorldSky(paint, this._world, this._elapsed, this._light.day / 255, this._weather);
            }) : null;
            if (worldSky) scene.add_child(worldSky);
            const clouds = [...CLOUDS, ...EXTRA_CLOUDS].slice(0, this._world?.id === 'kelp' ? 0 : this._weather.clouds).map(spec => {
                const mask = this._data.clouds[spec.bank];
                const cloud = { spec, x: 0, y: 0 };
                cloud.area = drawingArea(mask.w, mask.h, paint => {
                    paintCloud(paint, mask, spec, this._light, cloud.x, cloud.y, this._weather);
                });
                cloud.area.set_scale(spec.scale, spec.scale * skyScale);
                scene.add_child(cloud.area);
                return cloud;
            });

            const birds = desert ? null : drawingArea(WIDTH, 104, (paint, cr) => {
                cr.translate(0, -138);
                paintBirds(paint, this._elapsed, this._light, this._weather);
            }, Cairo.Antialias.DEFAULT);
            if (birds) {
                birds.set_position(0, 138);
                scene.add_child(birds);
            }

            const terrain = desert && !this._world ? newLayers(scene, WIDTH, HEIGHT) : [];
            const worldArt = this._world ? drawingArea(WIDTH * 2, HEIGHT * 2, (_paint, cr) => {
                cr.scale(2, 2);
                paintWorldArt(cr, Cairo, this._worldSurface, this._light.day / 255, this._light.sunlight, this._world);
            }, Cairo.Antialias.DEFAULT) : null;
            if (worldArt) { worldArt.set_scale(.5, .5); scene.add_child(worldArt); }
            const top = this._world ? 0 : (desert ? DESERT_FX_TOP : WATER_TOP);
            const shore = drawingArea(WIDTH, HEIGHT - top, (paint, cr) => {
                cr.translate(0, -top);
                if (this._world) {
                    paintWorldMotion(paint, this._world, this._elapsed, this._light, this._weather);
                } else if (desert) {
                    if (this._theme === 'plateau')
                        paintRockShadows(paint, this._light, this._weather);
                    paintDesert(paint, this._elapsed, this._light, this._theme, this._weather);
                    if (this._theme === 'dunes')
                        paintDuneSand(paint, this._elapsed, this._light, this._weather);
                    if (this._theme === 'oasis')
                        paintFireflies(paint, this._elapsed, this._phase, this._weather);
                } else {
                    paintWater(paint, this._elapsed, this._light, this._data.coast, this._weather);
                    paintFoam(paint, this._elapsed, this._light, this._data.coast, this._weather);
                    paintGrass(paint, this._elapsed, this._light, this._weather);
                }
            });
            shore.set_position(0, top);
            scene.add_child(shore);
            const palms = this._theme === 'oasis' ? this._layout.palms.map(([x1, y1, x2, y2]) => {
                const crown = new St.Widget({
                    width: x2 - x1, height: y2 - y1, x: x1, y: y1, reactive: false,
                    layout_manager: new Clutter.FixedLayout(),
                });
                crown.set_pivot_point(0.5, 0.67);
                scene.add_child(crown);
                return { crown, layers: newLayers(crown, x2 - x1, y2 - y1) };
            }) : [];
            const atmosphere = (this._weather.dim || this._weather.mist || this._weather.rain || this._weather.snow) ? drawingArea(WIDTH, HEIGHT, (paint, cr) => {
                if (this._world?.window) {cr.rectangle(...this._world.window);cr.clip();}
                if (this._world?.id !== 'kelp') paintAtmosphere(paint, cr, Cairo, this._weather, this._light.day / 255, this._elapsed);
            }, Cairo.Antialias.DEFAULT) : null;
            if (atmosphere)
                scene.add_child(atmosphere);
            this._group.add_child(root);
            this._views.push({ root, sky, horizon, celestial, clouds, birds, shore, terrain, palms, skyScale, atmosphere, worldArt, worldSky });
        }
        this._updateSky();
        this._updateTerrain();
        for (const view of this._views)
            this._group.set_child_above_sibling(view.root, null);
        this._animateViews(true);
    }

    _tick() {
        const monotonic = GLib.get_monotonic_time();
        this._elapsed = (monotonic - this._motionStart) / 1_000_000;
        let solarChanged = false;
        if (monotonic >= this._nextSolar) {
            solarChanged = this._updateSolarFrame(monotonic);
            this._nextSolar = monotonic + SOLAR_INTERVAL;
        }
        const repaintClouds = solarChanged || this._elapsed >= this._nextTint;
        if (repaintClouds)
            this._nextTint = this._elapsed + CLOUD_TINT_INTERVAL;

        this._animateViews(repaintClouds);
    }

    _animateViews(repaintClouds) {
        const repaintWeather = repaintClouds || this._weather.rain || this._weather.snow || this._elapsed >= this._nextWeather;
        if (repaintWeather)
            this._nextWeather = this._elapsed + .125;
        for (const view of this._views) {
            if (!view.root.is_mapped())
                continue;
            for (const cloud of view.clouds) {
                [cloud.x, cloud.y] = cloudPosition(cloud.spec, this._elapsed * this._weather.cloudSpeed);
                cloud.area.set_position(cloud.x, cloud.y * view.skyScale);
                if (repaintClouds)
                    cloud.area.queue_repaint();
            }
            for (const [i, palm] of view.palms.entries())
                palm.crown.rotation_angle_z = palmAngle(i, this._elapsed, this._weather);
            view.shore.queue_repaint();
            if (view.birds) {
                const showBirds = this._light.day > 10;
                view.birds.visible = showBirds;
                if (showBirds)
                    view.birds.queue_repaint();
            }
            if (repaintWeather) {
                view.atmosphere?.queue_repaint();
                view.worldSky?.queue_repaint();
            }
        }
    }

    _destroyViews() {
        for (const view of this._views ?? [])
            view.root.destroy();
        this._views = [];
    }

    disable() {
        if (this._tickId)
            GLib.Source.remove(this._tickId);
        if (this._monitorSignal)
            Main.layoutManager.disconnect(this._monitorSignal);
        if (this._backgroundSignal)
            this._group.disconnect(this._backgroundSignal);
        for (const id of this._settingsSignals ?? [])
            this._settings.disconnect(id);
        this._backgroundSync?.restore();
        this._weatherFeed?.stop();
        this._settings?.set_string('weather-status', '');

        this._settingsSignals = [];
        this._backgroundSync = null;
        this._phase = null;
        this._celestial = null;
        this._tickId = 0;
        this._monitorSignal = 0;
        this._backgroundSignal = 0;
        this._destroyViews();
        this._group = null;
        this._skyCache = null;
        this._location = null;
        this._settings = null;
        this._coordinates = null;
        this._data = null;
        this._layout = null;
        this._terrainCache = null;
        this._worldSurface = null;
        this._worldSurfaceId = null;
        this._world = null;
        this._worldPreview = null;
        this._worldPreviewTime = 0;
        this._schedule = null;
        this._light = null;
        this._weather = null;
        this._weatherFeed = null;
        this._lunar = null;
        this._lunarTable = null;
        this._presets = null;
    }
}
