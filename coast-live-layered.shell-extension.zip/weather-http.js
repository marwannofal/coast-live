// SPDX-License-Identifier: GPL-2.0-or-later
import Gio from 'gi://Gio';
import GLib from 'gi://GLib';

export class WeatherHttp {
    request(url) {
        const cancellable = new Gio.Cancellable();
        return {cancel: () => cancellable.cancel(), promise: this._fetch(url, cancellable)};
    }

    async _fetch(url, cancellable) {
        const {default: Soup} = await import('gi://Soup?version=3.0');
        if (cancellable.is_cancelled())
            throw new Error('Weather request cancelled.');
        this._session ??= new Soup.Session({timeout: 10, user_agent: 'Coast Live/11'});
        const message = Soup.Message.new('GET', url);
        message.set_flags(Soup.MessageFlags.NO_REDIRECT);
        const body = await new Promise((resolve, reject) => {
            this._session.send_and_read_async(message, GLib.PRIORITY_DEFAULT, cancellable, (source, result) => {
                try {
                    resolve(source.send_and_read_finish(result));
                } catch (error) {
                    reject(error);
                }
            });
        });
        if (message.get_status() !== Soup.Status.OK || body.get_size() > 65536)
            throw new Error('Unexpected Open-Meteo response.');
        return JSON.parse(new TextDecoder().decode(body.get_data()));
    }
}
