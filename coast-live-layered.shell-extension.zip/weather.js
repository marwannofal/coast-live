// SPDX-License-Identifier: GPL-2.0-or-later
import { HEIGHT, WIDTH } from './scene.js';

export const WEATHER_IDS = ['clear', 'overcast', 'foggy', 'stormy'];
export const WEATHER_NAMES = ['Clear', 'Overcast', 'Foggy', 'Stormy'];
const wrap = (value, period) => ((value % period) + period) % period;
const rain = Array.from({length: 120}, (_, i) => [
    wrap((i + 1) * .61803399, 1), wrap((i + 1) * .75487767, 1), wrap((i + 1) * .56984029, 1),
]);

export function paintAtmosphere(paint, cr, Cairo, weather, day, elapsed) {
    if (weather.dim) {
        paint.color([14, 23, 40], weather.dim * (.78 + day * .22));
        paint.rectangle(0, 0, WIDTH, HEIGHT);
        paint.fill();
    }

    if (weather.mist) {
        const rgb = [0.48 + day * .25, .56 + day * .22, .70 + day * .13];
        const phase = Math.sin(elapsed * .17);
        const gradient = new Cairo.LinearGradient(0, 0, 0, HEIGHT);
        const stops = [[0, .08], [.34, .22], [.63 + .05 * phase, .78], [.85, .94], [1, .28]];
        for (const [stop, alpha] of stops)
            gradient.addColorStopRGBA(stop, ...rgb, alpha * weather.mist);
        cr.setSource(gradient);
        cr.rectangle(0, 0, WIDTH, HEIGHT);
        cr.fill();
    }

    if (weather.rain) {
        for (let layer = 0; layer < 2; layer++) {
            paint.color([182, 211, 232], (.15 + day * .14) * (layer ? 1 : .63));
            cr.setLineWidth(layer ? .84 : .60);
            for (let i = layer; i < weather.rain; i += 2) {
                const [left, top, size] = rain[i];
                const speed = 250 + size * 290;
                const y = wrap(top * HEIGHT + elapsed * speed, HEIGHT + 34) - 17;
                const x = wrap(left * WIDTH - elapsed * speed * .31, WIDTH + 34) - 17;
                const length = 7 + size * 13;
                cr.moveTo(x, y);
                cr.lineTo(x - length * .31, y + length);
            }
            cr.stroke();
        }
    }
}
