// SPDX-License-Identifier: GPL-2.0-or-later
const DAY = 86_400_000;
const TAU = 2 * Math.PI;
const SYNODIC_DAYS = 29.530588;
const wrap = value => ((value % 1) + 1) % 1;

export class LunarPhaseTable {
    constructor(bytes) {
        if (bytes.length < 8 || (bytes.length - 4) % 2)
            throw new Error('Invalid Coast Live lunar table.');
        this._table = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
        this._first = this._table.getInt32(0, true);
        this._last = this._first + (bytes.length - 4) / 2 - 1;
    }

    _sample(day) {
        return this._table.getUint16(4 + (day - this._first) * 2, true) / 65536;
    }

    at(time) {
        const day = time / DAY;
        let fraction;
        if (day < this._first || day >= this._last) {
            const edge = day < this._first ? this._first : this._last;
            fraction = wrap(this._sample(edge) + (day - edge) / SYNODIC_DAYS);
        } else {
            const start = Math.floor(day);
            const before = this._sample(start);
            fraction = wrap(before + wrap(this._sample(start + 1) - before) * (day - start));
        }
        const terminator = Math.cos(TAU * fraction);
        return { fraction, terminator, waxing: fraction < .5, illuminated: (1 - terminator) / 2 };
    }
}

// Points travel down the visible limb and back up the phase terminator.
export function traceLunarDisk(path, x, y, radius, phase) {
    const side = phase.waxing ? 1 : -1;
    const edge = (step, width) => {
        const angle = Math.PI * step / 36;
        path.lineTo(x + side * radius * width * Math.sin(angle), y - radius * Math.cos(angle));
    };
    path.moveTo(x, y - radius);
    for (let step = 1; step <= 36; step++)
        edge(step, 1);
    for (let step = 35; step >= 0; step--)
        edge(step, phase.terminator);
    path.closePath();
}
