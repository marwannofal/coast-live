// SPDX-License-Identifier: GPL-2.0-or-later
import { WIDTH, WATER_TOP } from './scene.js';
import { traceLunarDisk } from './lunar.js';

export const CELESTIAL_HEIGHT = 454;
const TAU = Math.PI * 2;
const clamp = value => Math.max(0, Math.min(1, value));
const smooth = value => value * value * (3 - 2 * value);
const mix = (a, b, amount) => a + (b - a) * amount;

const palettes = [
    [0, 'night'], [63, 'night'], [90, 'blue-hour'], [110, 'sunrise'],
    [173, 'morning'], [250, 'noon'], [328, 'evening'], [390, 'sunset'],
    [410, 'blue-hour'], [452, 'night'], [500, 'night'],
];

const sunColors = [
    [110, [255, 229, 152]], [173, [221, 250, 255]], [250, [231, 252, 255]],
    [328, [255, 218, 193]], [390, [255, 196, 99]],
];

function interval(keys, phase) {
    const index = keys.findIndex(([point]) => point > phase);
    if (index <= 0) {
        const value = keys.at(index === 0 ? 0 : -1)[1];
        return [value, value, 0];
    }
    const [start, first] = keys[index - 1];
    const [end, last] = keys[index];
    return [first, last, smooth((phase - start) / (end - start))];
}

export function skyPalette(phase) {
    return interval(palettes, phase);
}

export function celestialState(phase) {
    const angle = Math.PI * (phase - 110) / 280;
    const altitude = Math.sin(angle);
    const sun = [
        480 - 314 * Math.cos(angle),
        altitude >= 0 ? WATER_TOP - 356 * altitude ** 1.30 : WATER_TOP - 472 * altitude,
        smooth(clamp(Math.min(phase - 99, 401 - phase) / 11)),
    ];
    const moonTime = phase >= 410 ? phase - 410 : phase + 90;
    const progress = moonTime / 180;
    const moon = [
        147 + 660 * progress,
        371 - 211 * Math.sin(Math.PI * progress),
        smooth(clamp(Math.min(moonTime, 180 - moonTime) / 31)),
    ];
    const [first, last, weight] = interval(sunColors, phase);
    const sunlight = first.map((channel, i) => mix(channel, last[i], weight));
    return { sun, moon, altitude, sunlight };
}

function source(cr, color, opacity) {
    const [red, green, blue] = color.map(value => value / 255);
    cr.setSourceRGBA(red, green, blue, opacity);
}

function disk(cr, x, y, radius) {
    cr.moveTo(x + radius, y);
    cr.arc(x, y, radius, 0, TAU);
    cr.closePath();
}

function glow(cr, Cairo, x, y, radius, color, opacity) {
    const pattern = new Cairo.RadialGradient(x, y, 0, x, y, radius);
    const [r, g, b] = color.map(value => value / 255);
    for (let i = 0; i <= 12; i++) {
        const position = i / 12;
        const fade = i === 12 ? 0 : Math.exp(-.5 * (2.9 * position) ** 2);
        pattern.addColorStopRGBA(position, r, g, b, opacity * fade);
    }
    cr.setSource(pattern);
    cr.rectangle(x - radius, y - radius, radius * 2, radius * 2);
    cr.fill();
}

function reflection(cr, Cairo, x, color, opacity, start, spread, growth, falloff) {
    for (let y = start; y < CELESTIAL_HEIGHT; y++) {
        const depth = y - start;
        const width = spread + growth * depth;
        const pattern = new Cairo.LinearGradient(x - width * 3, 0, x + width * 3, 0);
        const [r, g, b] = color.map(value => value / 255);
        for (const [stop, weight] of [[0, 0], [1 / 6, .135], [1 / 3, .607], [.5, 1], [2 / 3, .607], [5 / 6, .135], [1, 0]])
            pattern.addColorStopRGBA(stop, r, g, b, opacity * weight * Math.exp(-depth / falloff));
        cr.setSource(pattern);
        cr.rectangle(x - width * 3, y, width * 6, 1);
        cr.fill();
    }
}

let seed = 137;
function random() {
    seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0;
    return seed / 2 ** 32;
}
const stars = Array.from({ length: 28 }, () => [
    Math.floor(18 + random() * 925), Math.floor(17 + random() * 290), random(), random() * TAU,
]);

export function paintCelestial(cr, Cairo, phase, state, desert, lunar, weather, skyScale = 1) {
    const { sun: [sx, rawSy, day], moon: [mx, rawMy, night], altitude, sunlight } = state;
    const sy = rawSy * skyScale, my = rawMy * skyScale;
    const moonlight = night * lunar.illuminated * weather.light;
    cr.save();
    cr.rectangle(0, 0, WIDTH, WATER_TOP * skyScale);
    cr.clip();

    if (day) {
        const height = Math.max(0, altitude);
        glow(cr, Cairo, sx, sy, mix(64, 98, height) * 2.9, sunlight, day * weather.light * mix(.84, .70, height));
        source(cr, [255, 255, mix(236, 255, height)], day * weather.light);
        disk(cr, sx, sy, 14.9);
        cr.fill();
    }
    if (night) {
        for (const [x, y, size, twinkle] of stars) {
            const intensity = (.19 + .62 * size) * (.83 + .17 * Math.sin(TAU * phase / 50 + twinkle));
            source(cr, [234, 227, 255], intensity * night * weather.light);
            cr.rectangle(x, y * skyScale, 1, 1);
            if (size > .85) {
                cr.rectangle(x + 1, y * skyScale, .6, .6);
                cr.rectangle(x, y * skyScale + 1, .6, .6);
            }
            cr.fill();
        }
        if (lunar.illuminated > .002) {
            glow(cr, Cairo, mx, my, Math.sqrt(325) * 2.9, [187, 148, 250], .13 * moonlight);
            source(cr, [255, 246, 251], night * weather.light);
            traceLunarDisk(cr, mx, my, 11.8, lunar);
            cr.fill();
        }
    }
    cr.restore();

    if (desert)
        return;
    const sunReflection = clamp(1 - Math.abs(altitude) * 3.7) * day * weather.light * .5;
    if (sunReflection)
        reflection(cr, Cairo, sx, sunlight, sunReflection, WATER_TOP, 31, 3.4, 12);
    if (moonlight > .001)
        reflection(cr, Cairo, mx, [145, 155, 231], moonlight * .16, 426, 16, 2.3, 15);
}
