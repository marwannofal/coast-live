// SPDX-License-Identifier: GPL-2.0-or-later
export const LIVE_MINUTE = -1;
export const PREVIEW_LIFETIME_MS = 90_000;
export const validMinute = minute => Number.isInteger(minute) && minute >= 0 && minute < 1440;

export function localMinute(now) {
    const date = new Date(now);
    return date.getHours() * 60 + date.getMinutes();
}

export function effectiveTime(now, fixedMinute, preview) {
    let minute = fixedMinute;
    let previewing = false;
    const match = /^(\d{1,4}):(\d{10,15})$/.exec(preview);
    if (match) {
        const requested = Number(match[1]);
        const remaining = Number(match[2]) - now;
        if (validMinute(requested) && remaining > 0 && remaining <= PREVIEW_LIFETIME_MS) {
            minute = requested;
            previewing = true;
        }
    }
    if (!validMinute(minute))
        return { time: now, previewing };
    const date = new Date(now);
    date.setHours(Math.floor(minute / 60), minute % 60, 0, 0);
    return { time: date.getTime(), previewing };
}
