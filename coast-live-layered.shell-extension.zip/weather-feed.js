// SPDX-License-Identifier: GPL-2.0-or-later
export const WEATHER_CREDIT = 'https://open-meteo.com/';
const ENDPOINT = 'https://api.open-meteo.com/v1/forecast';
const FIELDS = 'weather_code,cloud_cover,wind_speed_10m,wind_gusts_10m,precipitation,snowfall';
const REFRESH = 15 * 60_000;
const RETRY = 5 * 60_000;
const MAX_AGE = 90 * 60_000;
const clamp = (x, lo = 0, hi = 1) => Math.max(lo, Math.min(hi, x));

export function locationKey([lat, lon]) {
    return (Math.round(lat * 100) / 100).toFixed(2) + ',' +
        (Math.round(lon * 100) / 100).toFixed(2);
}

export function weatherUrl(key) {
    const [lat, lon] = key.split(',');
    return ENDPOINT + '?latitude=' + lat + '&longitude=' + lon +
        '&current=' + FIELDS + '&wind_speed_unit=kmh&timeformat=unixtime&timezone=GMT&forecast_days=1';
}

export function parseWeather(payload, now) {
    const current = payload?.current;
    if (!current || !Number.isInteger(current.weather_code) || !Number.isFinite(current.cloud_cover) ||
        !Number.isFinite(current.wind_speed_10m) || !Number.isInteger(current.time))
        throw new Error('Incomplete Open-Meteo current conditions.');
    const observed = current.time * 1000;
    if (observed > now + 900_000 || observed < now - MAX_AGE)
        throw new Error('Open-Meteo returned conditions outside the freshness window.');

    const code = current.weather_code;
    const fog = code === 45 || code === 48;
    const thunder = code >= 95 && code <= 99;
    const snow = (code >= 71 && code <= 77) || code === 85 || code === 86 || current.snowfall > 0;
    const precip = Number.isFinite(current.precipitation) ? Math.max(0, current.precipitation) : 0;
    const wet = thunder || (!snow && ((code >= 51 && code <= 67) || (code >= 80 && code <= 82) || precip > .02));
    const cloudPercent = clamp(current.cloud_cover, 0, 100);
    const cloud = cloudPercent / 100;
    const windSpeed = clamp(current.wind_speed_10m, 0, 200);
    const gusts = Number.isFinite(current.wind_gusts_10m) ? clamp(current.wind_gusts_10m, windSpeed, 220) : windSpeed;
    const wind = clamp(.38 + (.8 * windSpeed + .2 * gusts) / 25, .38, 2.8);
    const label = thunder ? 'Thunderstorm' : snow ? 'Snow' : fog ? 'Fog' : wet ? 'Rain' :
        cloud >= .82 ? 'Overcast' : cloud >= .30 ? 'Partly cloudy' : 'Clear';

    const preset = {
        clouds: clamp(Math.round(12 * cloud), thunder ? 9 : 0, 12),
        cloudOpacity: .52 + cloud * .87,
        cloudSpeed: .40 + wind * .69,
        wind,
        wave: clamp(.38 + wind * .66 + (wet ? .17 : 0), .40, 2.35),
        dust: fog || snow || wet ? .25 : clamp(.6 + wind * .43, .75, 1.45),
        dim: fog ? .07 : clamp(cloud * .17 + (wet ? .09 : 0) + (thunder ? .08 : 0)),
        mist: fog ? .65 : snow ? .24 : thunder ? .14 : wet ? .10 : cloud * .043,
        rain: wet ? Math.round(clamp((thunder ? 92 : 25) + precip * 38, 0, 120)) : 0,
        snow: snow ? Math.round(clamp(38 + (Number.isFinite(current.snowfall) ? current.snowfall : 0) * 82, 0, 120)) : 0,
        light: clamp(fog ? .37 : 1 - cloud * .42 - (wet ? .15 : 0) - (thunder ? .14 : 0), .23, 1),
    };
    return {observed, label, cloud: Math.round(cloudPercent), wind: Math.round(windSpeed), preset};
}

export class WeatherFeed {
    constructor(request, changed, now = Date.now, monotonic = Date.now) {
        this._request = request;
        this._changed = changed;
        this._now = now;
        this._monotonic = monotonic;
        this._key = null;
        this._version = 0;
        this._state = null;
    }

    get state() { return this._state; }

    update(coordinates) {
        const key = locationKey(coordinates);
        const monotonic = this._monotonic();
        if (key !== this._key) {
            this.stop();
            this._key = key;
            this._next = monotonic + 1000;
            this._publish({key, status: 'loading', reading: null});
        }
        if (this._state.reading && this._now() - this._state.reading.observed > MAX_AGE)
            this._publish({key, status: 'offline', reading: null});
        if (this._pending || monotonic < this._next)
            return;
        this._pending = true;
        const version = this._version;
        const pending = this._request(weatherUrl(key));
        this._cancel = pending.cancel;
        pending.promise.then(payload => {
            if (version !== this._version)
                return;
            const reading = parseWeather(payload, this._now());
            this._finish(REFRESH);
            this._publish({key, status: 'live', reading});
        }).catch(() => {
            if (version !== this._version)
                return;
            this._finish(RETRY);
            this._publish({key, status: 'offline', reading: this._state.reading});
        });
    }

    _finish(delay) {
        this._pending = false;
        this._cancel = null;
        this._next = this._monotonic() + delay;
    }

    _publish(state) {
        this._state = state;
        this._changed(state);
    }

    stop() {
        this._version++;
        this._cancel?.();
        this._pending = false;
        this._cancel = null;
        this._state = null;
        this._key = null;
    }
}

export function describeWeather(state) {
    const {key, status, reading} = state;
    const site = key.replace(',', ', ');
    if (!reading)
        return (status === 'loading' ? 'Fetching weather' : 'Weather unavailable · Clear fallback') + ' · ' + site;
    const age = status === 'offline' ? ' · Cached' : '';
    return reading.label + ' · ' + reading.cloud + '% cloud · ' + reading.wind +
        ' km/h wind · ' + site + age;
}
