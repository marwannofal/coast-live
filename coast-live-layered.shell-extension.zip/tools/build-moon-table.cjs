// SPDX-License-Identifier: GPL-2.0-or-later
// Requires astronomy-engine@2.1.19. The packaged table is data only.
const fs = require('node:fs');
const {MoonPhase} = require('astronomy-engine');
const first = Date.UTC(1900, 0, 1) / 86400000;
const last = Date.UTC(2151, 0, 1) / 86400000;
const result = Buffer.alloc(4 + (last - first + 1) * 2);
result.writeInt32LE(first);
for (let day = first; day <= last; day++) {
    const angle = MoonPhase(new Date(day * 86400000));
    result.writeUInt16LE(Math.round(angle * 65536 / 360) % 65536, 4 + (day - first) * 2);
}
fs.writeFileSync(process.argv[2] ?? 'data/moon-phases.bin', result);
