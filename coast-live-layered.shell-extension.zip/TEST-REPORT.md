# Coast Live Worlds verification report

Release: GNOME version 12; Android Coast Live Worlds 1.0 (versionCode 1), package org.coastlive.worlds.

## Completed checks

| Check | Result and coverage |
| --- | --- |
| Assets | PASS: 20 distinct RGBA terrain illustrations at 1672 × 941, transparent sky, exact matching bytes and catalogs on both platforms |
| GNOME lifecycle simulation | PASS: 24 scenes × four manual weather presets × two monitors, four frame rates, fixed/preview/local time, monitor changes, disable/re-enable and cleanup |
| Solar/time/weather regression | PASS: preview expiry and invalid values, manual weather and cached-data fallback, rounded coordinates, lunar cycle, solar schedules at Amman, Beijing, Sydney and polar latitudes |
| Native GJS/Cairo scene rendering | PASS: 60 renders, 20 new scenes × day/dusk/night; visual review of the complete set |
| Native sun geometry | PASS: eight combinations of horizon and render scale; disk horizontal/vertical diameter differs by at most one pixel |
| Native GNOME Appearance snapshots | PASS: 144 generated 1920 × 1080 PNGs, 24 scenes × three times × clear/stormy, using the actual snapshot method with Cairo/Gio |
| Android host tests | PASS: 18 JUnit tests under Robolectric native graphics on API 28 and 35; final run 47.634 seconds |
| Android rendering matrix | PASS: 384 scene/weather/orientation combinations across the two Android API levels |
| Android motion and lighting | PASS: all 20 new scenes change with elapsed animation time and day/night lighting |
| Android circular sun | PASS: 138 scene/viewport/API cases, within one pixel |
| Android controls | PASS: all 24 scene choices, five weather modes, four FPS modes, fixed/local time, saved selection, invalid-scene fallback, custom/system coordinates, moon phases and weather caching |
| Display shapes | PASS: host render checks include phone, tablet, portrait, landscape and 3440 × 1440 ultrawide shapes |
| Packaging | Strict GNOME schemas compiled; Android compiled for SDK 35, min SDK 24, DEX generated, APK zip-aligned, v1/v2/v3 signatures verified |

The snapshot matrix was run before the last decorative planet refinement. That refinement was subsequently covered by the final native scene renders, lifecycle checks, and full Android test suite.

## Limits

No physical Android device, Android launcher/lock-screen integration, or live GNOME Shell compositor was available for this validation. The GNOME lifecycle harness simulates Shell objects; native Cairo checks validate painting and snapshots separately. GNOME 45–50 are declared versions, not six tested desktop installations. Android 7.0 is the minimum API target; native host tests covered Android 9 and 15.

No sustained-FPS, GPU utilization, battery-drain, or memory-leak benchmark on real hardware is claimed. Requested 50 FPS may be limited by the device. Test providers are simulated for deterministic weather checks; no real-coordinate weather accuracy claim is made.

See tests/README.md for reproduction instructions. The APK installs alongside the previous app because the prior signing key was unavailable. Keep the separate private signing backup for future updates; it is excluded from all public packages.
