# Coast Live 9

Coast Live is a GNOME Shell extension with four animated scenes. The solar clock follows your location. Seven background images provide the base lighting for all four scenes. The renderer blends up to two of them at a time and draws the sun, moon, stars, glow, and water reflections on a transparent layer. The live renderer calculates their position from time. Clouds, waves, grass, dust, reeds, and palms use the existing scene animations.

The seven shared background plates are 1920×1080 and retain the original pixel-art artwork. Thirty-three stills per scene are reserved for GNOME's background integration. The Sahara scenes also use their existing terrain and palm sprites.

## Install

This extension declares support for GNOME Shell 45–50. Download the ZIP to Downloads. When upgrading, keep your existing release ZIP for rollback and disable Coast Live before installing.

```sh
gnome-extensions disable coast-live@coastlive
gnome-extensions install --force ~/Downloads/coast-live-layered.shell-extension.zip
```

Sign out and back in to GNOME, then enable the extension.

```sh
gnome-extensions enable coast-live@coastlive
gnome-extensions info coast-live@coastlive
```

Check for version 9 and state ACTIVE.

## Settings

```sh
gnome-extensions prefs coast-live@coastlive
```

Pick Coast, Golden Dunes, Sandstone Plateau, or Desert Oasis. The **Weather** setting applies to every scene.

| Preset | Look and motion |
| --- | --- |
| Clear | The original sky and baseline motion |
| Overcast | More cloud cover and muted sunlight |
| Foggy | Drifting haze and calmer wind and water |
| Stormy | Darker clouds, slanting rain, and stronger wind and waves |

Weather affects the motion each scene has, including Coast grass and waves, Sahara dust and tufts, and Oasis palms, reeds, and ripples. The moon follows an offline astronomical phase table and draws waxing and waning shapes. Its light scales with illumination, including in the Coast sea and Oasis pond. The moon's position in the scene is artistic.

Set animation speed independently of the solar clock. The extension uses the representative location for your system time zone, or you can supply your own latitude and longitude. Sun and moon paths retain Coast Live's artistic geometry. Optional GNOME background integration uses a matching still for the appearance settings, activities overview, and lock screen.

## Build

Compile the schema after changing it using `glib-compile-schemas --strict schemas`. Package all files with `metadata.json` at the ZIP root.

The included procedural asset generator can regenerate the seven plates and Coast stills with Node.js and FFmpeg. Run these commands from the project directory in Bash.

```bash
mkdir -p sky themes/coast
node tools/render-art.cjs --plates | ffmpeg -v error -y -f rawvideo \
    -pix_fmt rgb24 -video_size 960x540 -framerate 1 -i - \
    -vf scale=1920:1080:flags=neighbor -c:v png sky/plate-%02d.png
names=(night sunrise morning noon evening sunset blue-hour)
for i in "${!names[@]}"; do
    printf -v plate 'sky/plate-%02d.png' "$((i + 1))"
    mv "$plate" "sky/${names[$i]}.png"
done
node tools/render-art.cjs --stills | ffmpeg -v error -y -f rawvideo \
    -pix_fmt rgb24 -video_size 960x540 -framerate 1 -i - \
    -vf scale=1920:1080:flags=neighbor -c:v mjpeg -pix_fmt yuvj420p \
    -q:v 5 -start_number 0 themes/coast/still-%02d.jpg
```

To regenerate the Sahara artwork and stills, run `python3 tools/build-sahara.py themes/source/dunes.png themes/source/plateau.png themes/source/oasis.png` after rebuilding the Coast stills. This requires NumPy, Pillow, and SciPy.

The lunar table uses daily geocentric phase samples from Astronomy Engine 2.1.19, from 1900 through 2150. Dates outside that range use a mean synodic month anchored to the nearest sample. Rebuild it with `node tools/build-moon-table.cjs` after installing that version of `astronomy-engine`. The weather tuning values are in `data/weather.json`. GNOME background integration uses bundled static stills.

## License

The extension and its bundled artwork are licensed GPL-2.0-or-later. See `COPYING`. The timezone tables are from the public-domain IANA Time Zone Database. The solar clock uses the NOAA solar equations.
