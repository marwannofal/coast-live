// SPDX-License-Identifier: GPL-2.0-or-later
// Called only when lighting changes; animation never decodes or recolors artwork.
export function paintWorldArt(cr, Cairo, surface, day, sunlight, world = null) {
    cr.save();
    cr.pushGroup();
    cr.save();
    cr.scale(960 / surface.getWidth(), 540 / surface.getHeight());
    cr.setSourceSurface(surface, 0, 0); cr.paint(); cr.restore();
    cr.setOperator(Cairo.Operator.ATOP);
    cr.setSourceRGBA(.025,.045,.13,(1-day)*.78);
    cr.rectangle(0,0,960,540); cr.fill();
    const warmth = Math.max(0, (sunlight[0]-sunlight[2])/255) * day * .24;
    cr.setSourceRGBA(1,.43,.19,warmth);
    cr.rectangle(0,0,960,540); cr.fill();
    cr.setOperator(Cairo.Operator.OVER);
    cr.popGroupToSource(); cr.paint();
    if (day < .99) for (const [x,y,r,g,b,power] of world?.emission ?? []) {
        cr.setSourceRGBA(r/255,g/255,b/255,(1-day)*.95*power);
        cr.rectangle(x,y,2,2);cr.fill();
    }
    cr.restore();
}

export function paintSkyPlate(cr, surface, skyScale, opacity = 1, coast = false) {
    cr.save();
    if (coast) {
        cr.scale(960 / surface.getWidth(), 540 / surface.getHeight());
        cr.setSourceSurface(surface,0,0);cr.paintWithAlpha(opacity);
    } else {
        const sourceH = Math.round(surface.getHeight() * 424 / 540), targetH = Math.round(424 * skyScale);
        cr.save();cr.rectangle(0,0,960,targetH);cr.clip();
        cr.scale(960 / surface.getWidth(),targetH/sourceH);cr.setSourceSurface(surface,0,0);cr.paintWithAlpha(opacity);cr.restore();
        cr.rectangle(0,targetH,960,540-targetH);cr.clip();cr.translate(0,targetH);
        cr.scale(960 / surface.getWidth(),540-targetH);cr.setSourceSurface(surface,0,1-sourceH);cr.paintWithAlpha(opacity);
    }
    cr.restore();
}
