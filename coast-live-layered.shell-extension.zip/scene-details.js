// SPDX-License-Identifier: GPL-2.0-or-later
import { WIDTH, WATER_TOP } from './scene.js';

const PI = Math.PI;
const TAU = PI * 2;
const wrap = (x, n) => x - Math.floor(x / n) * n;
const clamp = x => Math.max(0, Math.min(1, x));
const mix = (a, b, f) => a + (b - a) * f;
const seed = (i, step) => wrap((i + 1) * step, 1);
const sand = Array.from({length: 108}, (_, i) => [
    seed(i, .61803399), seed(i, .75487767), seed(i, .56984029), seed(i, .41421356),
]);
const lights = sand.slice(0, 31);

export function paintBirds(paint, time, light, weather) {
    const daylight = light.day / 255;
    const opacity = daylight * (1 - weather.mist) * (weather.rain || weather.snow ? .10 : .72);
    if (opacity < .025)
        return;
    const flock = wrap(410 + time * (9 + weather.wind * 2), WIDTH + 165) - 85;
    paint.color([39, 46, 65], opacity);
    paint.lineWidth(1.25);
    for (let i = 0; i < 6; i++) {
        const x = flock - i * 12;
        const y = 173 + i * 5 + 9 * Math.sin(time * .48 + i * .53);
        const wing = 2 + 2.7 * Math.sin(time * 5.4 + i * .9);
        const width = 5.5 - i * .28;
        paint.moveTo(x - width, y - wing);
        paint.curveTo(x - width * .58, y - wing - 1.2, x - 1.2, y - 1, x, y + .5);
        paint.curveTo(x + 1.1, y - 1, x + width * .60, y - wing - 1, x + width, y - wing);
    }
    paint.stroke();
}

export function paintFoam(paint, time, light, coast, weather) {
    paint.save();
    paint.moveTo(0, WATER_TOP + 4);
    paint.lineTo(WIDTH, WATER_TOP + 4);
    for (let i = coast.length - 1; i >= 0; i--)
        paint.lineTo(i * 2, coast[i] - .9);
    paint.close();
    paint.clip();
    const day = light.day / 255;
    for (let row = 0; row < 4; row++) {
        const phase = wrap(time * .15 * (.68 + weather.wave * .32) + row * .25, 1);
        const y = 432 + 27 * phase;
        const opacity = Math.sin(phase * PI) * (.12 + day * .31) * (.68 + weather.wave * .32);
        paint.color([207, 238, 239], opacity);
        paint.lineWidth(.48 + .70 * phase);
        const drift = time * (2 + row) * weather.wind;
        for (let i = 0; i < 14; i++) {
            const x = wrap(i * 87 + row * 41 - drift, WIDTH + 85) - 45;
            const length = 9 + 32 * seed(i + row * 3, .41421356);
            const height = Math.sin(x * .028 + row + time * .6) * (.45 + phase * weather.wave);
            paint.moveTo(x, y + height);
            paint.curveTo(x + length * .33, y + height - 1.6, x + length * .69, y + height + .9, x + length, y + height - .3);
        }
        paint.stroke();
    }
    paint.restore();
}

export function paintDuneSand(paint, time, light, weather) {
    const daylight = light.day / 255;
    for (let layer = 0; layer < 3; layer++) {
        const warm = [.69, .83, 1][layer];
        paint.color([155 + daylight * 98, 144 + daylight * 74, 168 - daylight * 26],
            (.10 + daylight * .30) * weather.dust * warm);
        paint.lineWidth(.6 + layer * .22);
        for (let i = layer; i < sand.length; i += 3) {
            const [a,b,c,d] = sand[i];
            const flow = wrap(time * (.018 + b * .022) * weather.wind + a, 1);
            const x = flow * (WIDTH + 40) - 20;
            const ridge = 441 - 87 * Math.sin(PI * clamp(x / WIDTH * .78));
            const y = ridge + (c - .3) * (25 + layer * 18) - 7 * Math.sin(flow * TAU + d * 5);
            const tail = 1 + (layer + 1) * (2 + d * 5) * Math.sqrt(weather.wind);
            paint.moveTo(x, y);
            paint.lineTo(x + tail, y - .75 - b * 1.7);
        }
        paint.stroke();
    }
}

export const ROCKS = [[475, 383, 79, 32], [820, 387, 36, 19], [69, 392, 30, 16]];

export function rockShadows(light, weather) {
    const [sunX, sunY, intensity] = light.sun;
    if (intensity < 4 || sunY >= WATER_TOP)
        return [];
    const low = clamp((sunY - 68) / (WATER_TOP - 68));
    const length = 17 + 143 * low ** 1.7;
    const opacity = intensity / 255 * (.12 + .14 * low) * (1 - weather.mist * .5);
    return ROCKS.map(([x,y,w,h]) => {
        const dx = Math.max(-1, Math.min(1, (x - sunX) / 230)) * length;
        const dy = h * .48 + length * .25;
        return {x,y,w,dx,dy,opacity};
    });
}

export function paintRockShadows(paint, light, weather) {
    for (const {x,y,w,dx,dy,opacity} of rockShadows(light, weather)) {
        paint.color([49, 29, 49], opacity);
        paint.moveTo(x - w, y);
        paint.lineTo(x - w * .52, y - 2);
        paint.lineTo(x + w * .5, y - 3);
        paint.lineTo(x + w, y + 3);
        paint.lineTo(x + dx + w * .50, y + dy * .78);
        paint.lineTo(x + dx + w * .28, y + dy);
        paint.lineTo(x + dx - w * .63, y + dy * .83);
        paint.close();
        paint.fill();
    }
}

export function fireflyStrength(phase, weather) {
    if (weather.rain || weather.snow)
        return 0;
    return clamp((phase - 1515) / 113) * clamp((1880 - phase) / 175) * (1 - weather.mist * .48);
}

export function paintFireflies(paint, time, phase, weather) {
    const dusk = fireflyStrength(phase, weather);
    if (dusk < .015)
        return;
    for (const [a,b,c,d] of lights) {
        const intensity = dusk * Math.max(0, Math.sin(time * (1.15 + c * 1.65) + d * TAU)) ** 2;
        if (intensity < .04)
            continue;
        const x = mix(160, 809, a) + 11 * Math.sin(time * .76 + b * TAU);
        const y = 437 + b * 71 + 5 * Math.cos(time * .86 + c * TAU);
        const size = 1.3 + .6 * c;
        paint.color([209, 225, 95], .12 * intensity);
        paint.circle(x,y,size * 3);
        paint.fill();
        paint.color([251, 245, 161], .89 * intensity);
        paint.circle(x,y,size);
        paint.fill();
    }
}
