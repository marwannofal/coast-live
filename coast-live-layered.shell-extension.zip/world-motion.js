// SPDX-License-Identifier: GPL-2.0-or-later
// Deterministic scene details: seconds from the animation clock, independent of solar time.
const TAU = 2 * Math.PI;
const wrap = (x, n) => ((x % n) + n) % n;
const noise = i => wrap(Math.sin(i * 127.1 + 37.7) * 43758.5453, 1);
const clamp = x => Math.max(0, Math.min(1, x));
function rect(p, rgb, a, x, y, w, h) {
    p.color(rgb, clamp(a)); p.rectangle(Math.round(x), Math.round(y), w, h); p.fill();
}
function polygon(p, points) {
    p.moveTo(...points[0]); for (const xy of points.slice(1)) p.lineTo(...xy); p.close();
}
function smoke(p, x, y, t, wind, day, seed = 0) {
    for (let i = 0; i < 12; i++) {
        const age = wrap(t * .18 + i / 12, 1), size = 3 + age * 11;
        const dx = age * 42 * wind + Math.sin(t + i) * 3;
        rect(p, [200,205,215], (1-age)*(.13+.10*day), x + dx - size/2, y - age * 75, size, size*.55);
    }
}
export function paintWorldSky(p, world, t, day, weather) {
    if (world.id === 'kelp') {
        rect(p,[7,83,111],.55+weather.dim*.3,0,0,960,540);
        for(let i=0;i<9;i++) {
            const x=90+i*100+Math.sin(t*.13+i)*24;
            p.color([121,225,220],day*weather.light*.05);
            polygon(p,[[x,0],[x+14,0],[x-95,540],[x-165,540]]);p.fill();
        }
    }
    if (world.aurora) {
        for (let x=0;x<960;x+=8) {
            const top=43+30*Math.sin(x*.007+t*.08)+18*Math.sin(x*.019-t*.12);
            for (let j=0;j<8;j++) rect(p,[60+j*9,221-j*5,174+j*6],(1-day)*weather.light*.09*(1-j/8),x,top+j*9,8,18);
        }
    }
    if (world.planet) {
        const cx=750,cy=106,radius=76,alpha=.72+.23*(1-day),tilt=-.27;
        const ring = front => {
            for(let band=0;band<6;band++) {
                const r=108+band*3;
                p.color(band%2?[206,186,194]:[154,143,183],alpha*.72);p.lineWidth(2);
                for(let k=0;k<=72;k++) {
                    const a=(front?0:Math.PI)+k*Math.PI/72;
                    const x=r*Math.cos(a),y=r*.24*Math.sin(a);
                    const px=cx+x*Math.cos(tilt)-y*Math.sin(tilt),py=cy+x*Math.sin(tilt)+y*Math.cos(tilt);
                    if(k===0)p.moveTo(px,py);else p.lineTo(px,py);
                }
                p.stroke();
            }
        };
        ring(false);
        const colors=[[157,138,180],[199,170,186],[215,184,171],[180,149,178],[139,125,169]];
        for(let y=-radius;y<radius;y+=2) {
            const half=Math.sqrt(Math.max(0,radius*radius-y*y));
            const band=wrap(Math.floor((y+radius)/9+Math.sin(y*.12)*.7),colors.length);
            rect(p,colors[band],alpha,cx-half,cy+y,half*2,2);
            rect(p,[63,64,110],alpha*.21,cx+half*.48,cy+y,half*.52,2);
        }
        ring(true);
    }
}
export function paintWorldMotion(p, world, t, light, weather) {
    const day=light.day/255, wind=Math.max(.15,weather.wind), night=1-day;
    const sun=light.sun, moon=light.moon;
    if (world.window) {p.save();p.rectangle(...world.window);p.clip();}
    if (world.water) {
        p.save();polygon(p,world.water);p.clip();
        const ys=world.water.map(v=>v[1]), top=Math.min(...ys), depth=540-top;
        for(let i=0;i<75;i++) {
            const d=noise(i+2), y=top+d*depth;
            const x=wrap(noise(i+100)*960+t*(2+d*9)*wind,960);
            const body=sun[2]>=moon[2]?sun:moon;
            const r=Math.exp(-(((x-body[0])/(32+d*85))**2))*body[2]/255;
            const color=world.bioluminescent?[70,232,207]:[163,203,228];
            rect(p,color,(.08+day*.12+r*.45+night*(world.bioluminescent?.23:0))*(.6+weather.wave*.4),x,y,3+d*15+r*16,1+d);
        }
        if(weather.rain) for(let i=0;i<18;i++) {
            const f=wrap(t*1.5+i*.37,1),x=noise(i+500)*960,y=top+noise(i+600)*depth;
            rect(p,[186,216,237],(1-f)*.28,x-f*7,y,2+f*14,1);
        }
        p.restore();
    }
    for(const [x,y] of world.plants??[]) {
        for(let i=0;i<5;i++) {
            const h=12+i*3, bend=Math.sin(t*(.8+wind*.45)+i+x)*h*.18*wind;
            p.color(world.plantColor??[114,160,88],.4+day*.5);p.lineWidth(1.5);
            p.moveTo(x+i*3,y);p.curveTo(x+i*3,y-h*.4,x+i*3+bend,y-h*.8,x+i*3+bend,y-h);p.stroke();
            rect(p,world.plantColor??[135,174,100],.6,x+i*3+bend-2,y-h,4,3);
        }
    }
    const particleColor=world.petals??world.leaves;
    if(particleColor) for(let i=0;i<22;i++) {
        const x=wrap(noise(i+30)*960+t*(8+noise(i)*12)*wind,980)-10;
        const y=wrap(noise(i+40)*560+t*(5+noise(i+2)*7),560)-10;
        rect(p,particleColor,.42+day*.45,x+7*Math.sin(t+i),y,2+Math.abs(Math.sin(t+i))*3,2);
    }
    if(world.window) p.restore();
    if(world.dust||world.embers) for(let i=0;i<36;i++) {
        const f=wrap(t*(.06+noise(i)*.08)*wind+noise(i+80),1);
        const y=world.embers?500-f*180:410+noise(i+81)*100-Math.sin(f*Math.PI)*12;
        rect(p,world.embers?[255,156,65]:[215,190,155],Math.sin(f*Math.PI)*(world.embers?.6:.2)*weather.dust,wrap(noise(i+90)*960+f*180,960),y,world.embers?2:4,1);
    }
    if(world.fireflies) for(let i=0;i<26;i++) {
        const a=night*Math.max(0,Math.sin(t*1.1+i*2.4))*(1-weather.dim)*.9;
        rect(p,world.bioluminescent?[77,255,219]:[216,242,128],a,90+noise(i+200)*780+Math.sin(t*.3+i)*12,310+noise(i+201)*195+Math.cos(t*.4+i)*6,2,2);
    }
    for(const [x,y] of world.glows??[]) {
        const a=night*(.11+.015*Math.sin(t*2.7+x));
        for(let s=22;s>=4;s-=6) rect(p,[255,190,91],a*.3,x-s/2,y-s/2,s,s);
    }
    if(world.rotor) {
        const [cx,cy,r,n]=world.rotor;
        for(let i=0;i<n;i++) {
            const a=t*.24*wind+i*TAU/n, dx=Math.cos(a),dy=Math.sin(a);
            const wide=n===4?7:2.2;
            p.color([191,160,111],.45+day*.5);
            polygon(p,[[cx+dx*8,cy+dy*8],[cx+dx*r,cy+dy*r],[cx+dx*r-dy*wide,cy+dy*r+dx*wide],[cx+dx*8-dy*wide,cy+dy*8+dx*wide]]);p.fill();
        }
        p.color([96,71,54],1);p.circle(cx,cy,3);p.fill();
    }
    if(world.train) {
        const [left,right,y]=world.train;
        const x=left+wrap(t*14,right-left+240)-180;
        p.save();p.rectangle(left,0,right-left,y+5);p.clip();
        for(let car=0;car<4;car++) {
            const cx=x-car*46;
            rect(p,[65,53,66],1,cx,y-21,43,17);
            rect(p,[126,61,68],.8,cx,y-18,43,11);
            for(let j=0;j<5;j++)rect(p,[255,207,113],.6+night*.35,cx+4+j*7,y-16,4,6);
            for(let j=0;j<2;j++){p.color([33,37,45],1);p.circle(cx+9+j*25,y-3,3.5);p.fill();}
        }
        rect(p,[38,44,50],1,x+35,y-22,30,18);rect(p,[38,44,50],1,x+56,y-29,5,14);
        smoke(p,x+58,y-29,t,wind,day);p.restore();
    } else for(const [x,y] of world.smoke??[]) smoke(p,x,y,t,wind,day);
    for(const [x,y,length] of world.waterfalls??[]) for(let i=0;i<30;i++) {
        const d=wrap(t*.22+i/30,1);rect(p,[187,229,247],.1+.35*Math.sin(d*Math.PI),x+Math.sin(i*3)*5,y+d*length,2,6);
    }
    if(world.fish) for(let i=0;i<12;i++) {
        const x=wrap(noise(i+12)*960+t*(9+i*.7),1000)-20, y=240+noise(i+15)*190+5*Math.sin(t+i);
        rect(p,[181,215,221],.75,x,y,9,3);rect(p,[101,157,175],.8,x-3,y-1+Math.sin(t*3+i),3,5);
    }
    if(world.bubbles) for(let i=0;i<28;i++) {
        p.color([168,224,239],.25);p.lineWidth(.6);p.circle(noise(i+87)*960+5*Math.sin(t+i),540-wrap(noise(i)*540+t*(12+i*.4),540),1+noise(i+21)*2);p.stroke();
    }
    if(world.shadows && sun[2]>0) {
        p.color([20,28,50],.1*sun[2]/255*weather.light);
        for(let i=0;i<6;i++){const x=80+i*70,y=400+i*12;polygon(p,[[x,y],[x+10,y],[x+10+(x-sun[0])*.18,y+30],[x+(x-sun[0])*.18,y+30]]);p.fill();}
    }
    // Rain/snow itself is the shared weather layer. Scene names do not force a forecast.
}
