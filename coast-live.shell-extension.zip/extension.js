// SPDX-License-Identifier: GPL-2.0-or-later
import Cairo from 'cairo';
import Clutter from 'gi://Clutter';
import Cogl from 'gi://Cogl';
import GdkPixbuf from 'gi://GdkPixbuf';
import GLib from 'gi://GLib';
import St from 'gi://St';

import { Extension } from 'resource:///org/gnome/shell/extensions/extension.js';
import * as Main from 'resource:///org/gnome/shell/ui/main.js';

import { BackgroundSync } from './background-sync.js';
import { LocalLocation } from './location.js';
import { solarFrame, solarSchedule } from './solar-clock.js';
import {
    CLOUDS, HEIGHT, WATER_TOP, WIDTH, cloudPosition, paintCloud, paintGrass, paintWater,
} from './scene.js';

const ANIMATION_INTERVAL_MS = { economy: 125, balanced: 67, smooth: 40, ultra: 20 };
const SOLAR_INTERVAL = 3_000_000;
const CLOUD_TINT_INTERVAL = 0.8;

function cairoPainter(cr) {
    return {
        color: (rgb, alpha) => cr.setSourceRGBA(rgb[0] / 255, rgb[1] / 255, rgb[2] / 255, alpha),
        rectangle: (x, y, width, height) => cr.rectangle(x, y, width, height),
        fill: () => cr.fill(),
        save: () => cr.save(),
        restore: () => cr.restore(),
        moveTo: (x, y) => cr.moveTo(x, y),
        lineTo: (x, y) => cr.lineTo(x, y),
        close: () => cr.closePath(),
        clip: () => cr.clip(),
    };
}

function drawingArea(width, height, paint) {
    const area = new St.DrawingArea({ width, height, reactive: false });
    area.connect('repaint', () => {
        const cr = area.get_context();
        try {
            cr.setOperator(Cairo.Operator.CLEAR);
            cr.paint();
            cr.setOperator(Cairo.Operator.OVER);
            cr.setAntialias(Cairo.Antialias.NONE);
            paint(cairoPainter(cr), cr);
        } finally {
            cr.$dispose();
        }
    });
    return area;
}

export default class CoastLive extends Extension {
    enable() {
        this._group = Main.layoutManager._backgroundGroup;
        if (!this._group)
            throw new Error('Coast Live could not locate the desktop background group.');

        try {
            const [ok, bytes] = this.dir.get_child('scene-data.json').load_contents(null);
            if (!ok)
                throw new Error('Coast Live could not load scene data.');
            this._data = JSON.parse(new TextDecoder().decode(bytes));
            if (this._data.frames.length !== 2000)
                throw new Error('Coast Live expects 2,000 solar lighting frames.');

            this._views = [];
            this._content = St.ImageContent.new_with_preferred_size(WIDTH, HEIGHT);
            this._settings = this.getSettings();
            this._location = new LocalLocation(this.path);
            this._motionStart = GLib.get_monotonic_time();
            this._elapsed = 0;
            this._coordinates = null;
            this._schedule = null;
            this._frame = -1;
            this._frameFile = null;
            this._nextSolar = 0;
            this._nextTint = 0;
            this._configureBackgroundSync();
            this._updateSolarFrame();
            this._buildViews();

            this._monitorSignal = Main.layoutManager.connect('monitors-changed', () => this._buildViews());
            this._backgroundSignal = this._group.connect('child-added', () => {
                for (const view of this._views)
                    this._group.set_child_above_sibling(view.root, null);
            });
            this._settingsSignals = [
                this._settings.connect('changed::animation-speed', () => this._startAnimation()),
                this._settings.connect('changed::match-gnome-background', () => this._configureBackgroundSync()),
            ];
            this._startAnimation();
        } catch (error) {
            this.disable();
            throw error;
        }
    }

    _startAnimation() {
        if (this._tickId)
            GLib.Source.remove(this._tickId);
        const mode = this._settings.get_string('animation-speed');
        this._tickId = GLib.timeout_add(GLib.PRIORITY_DEFAULT, ANIMATION_INTERVAL_MS[mode], () => {
            this._tick();
            return GLib.SOURCE_CONTINUE;
        });
    }

    _configureBackgroundSync() {
        this._backgroundSync?.restore();
        this._backgroundSync = this._settings.get_boolean('match-gnome-background')
            ? new BackgroundSync()
            : null;
        this._syncBackground();
    }

    _syncBackground() {
        if (this._backgroundSync && this._frameFile)
            this._backgroundSync.update(this._frameFile.get_uri(), GLib.get_monotonic_time());
    }

    _updateSolarFrame() {
        const time = Date.now();
        const { coordinates } = this._location.resolve(this._settings, time);
        if (!this._schedule || time < this._schedule.start || time >= this._schedule.end
            || coordinates.some((value, i) => value !== this._coordinates[i])) {
            this._schedule = solarSchedule(time, ...coordinates);
            this._coordinates = coordinates;
        }

        const frame = solarFrame(time, this._schedule);
        if (frame === this._frame) {
            this._syncBackground();
            return false;
        }

        const name = 'frame_' + String(frame).padStart(4, '0') + '.jpg';
        const file = this.dir.get_child('solar').get_child(name);
        const pixbuf = GdkPixbuf.Pixbuf.new_from_file(file.get_path());
        const args = [
            pixbuf.read_pixel_bytes(), Cogl.PixelFormat.RGB_888,
            pixbuf.width, pixbuf.height, pixbuf.rowstride,
        ];
        // Newer St versions take an explicit Cogl context.
        if (this._content.set_bytes.length === 6)
            args.unshift(global.stage.context.get_backend().get_cogl_context());
        if (!this._content.set_bytes(...args))
            throw new Error('Coast Live could not display ' + name);

        this._frame = frame;
        this._light = this._data.frames[frame];
        this._frameFile = file;
        this._syncBackground();
        return true;
    }

    _buildViews() {
        this._destroyViews();
        for (const monitor of Main.layoutManager.monitors) {
            const root = new St.Widget({
                x: monitor.x, y: monitor.y, width: monitor.width, height: monitor.height,
                clip_to_allocation: true, reactive: false, layout_manager: new Clutter.FixedLayout(),
            });
            const scene = new St.Widget({
                width: WIDTH, height: HEIGHT, reactive: false, layout_manager: new Clutter.FixedLayout(),
            });
            const scale = Math.max(monitor.width / WIDTH, monitor.height / HEIGHT);
            scene.set_scale(scale, scale);
            scene.set_position((monitor.width - WIDTH * scale) / 2, (monitor.height - HEIGHT * scale) / 2);
            root.add_child(scene);

            scene.add_child(new St.Widget({
                width: WIDTH, height: HEIGHT, reactive: false, content: this._content,
                content_gravity: Clutter.ContentGravity.RESIZE_FILL,
            }));

            const clouds = CLOUDS.map(spec => {
                const mask = this._data.clouds[spec.bank];
                const cloud = { spec, x: 0, y: 0 };
                cloud.area = drawingArea(mask.w, mask.h, paint => {
                    paintCloud(paint, mask, spec, this._light, cloud.x, cloud.y);
                });
                cloud.area.set_scale(spec.scale, spec.scale);
                scene.add_child(cloud.area);
                return cloud;
            });

            const shore = drawingArea(WIDTH, HEIGHT - WATER_TOP, (paint, cr) => {
                cr.translate(0, -WATER_TOP);
                paintWater(paint, this._elapsed, this._light, this._data.coast);
                paintGrass(paint, this._elapsed, this._light);
            });
            shore.set_position(0, WATER_TOP);
            scene.add_child(shore);
            this._group.add_child(root);
            this._views.push({ root, clouds, shore });
        }
        for (const view of this._views)
            this._group.set_child_above_sibling(view.root, null);
        this._animateViews(true);
    }

    _tick() {
        const monotonic = GLib.get_monotonic_time();
        this._elapsed = (monotonic - this._motionStart) / 1_000_000;
        let solarChanged = false;
        if (monotonic >= this._nextSolar) {
            solarChanged = this._updateSolarFrame();
            this._nextSolar = monotonic + SOLAR_INTERVAL;
        }
        const repaintClouds = solarChanged || this._elapsed >= this._nextTint;
        if (repaintClouds)
            this._nextTint = this._elapsed + CLOUD_TINT_INTERVAL;

        this._animateViews(repaintClouds);
    }

    _animateViews(repaintClouds) {
        for (const view of this._views) {
            if (!view.root.is_mapped())
                continue;
            for (const cloud of view.clouds) {
                [cloud.x, cloud.y] = cloudPosition(cloud.spec, this._elapsed);
                cloud.area.set_position(cloud.x, cloud.y);
                if (repaintClouds)
                    cloud.area.queue_repaint();
            }
            view.shore.queue_repaint();
        }
    }

    _destroyViews() {
        for (const view of this._views ?? [])
            view.root.destroy();
        this._views = [];
    }

    disable() {
        if (this._tickId)
            GLib.Source.remove(this._tickId);
        if (this._monitorSignal)
            Main.layoutManager.disconnect(this._monitorSignal);
        if (this._backgroundSignal)
            this._group.disconnect(this._backgroundSignal);
        for (const id of this._settingsSignals ?? [])
            this._settings.disconnect(id);
        this._backgroundSync?.restore();

        this._settingsSignals = [];
        this._backgroundSync = null;
        this._frameFile = null;
        this._tickId = 0;
        this._monitorSignal = 0;
        this._backgroundSignal = 0;
        this._destroyViews();
        this._group = null;
        this._content = null;
        this._location = null;
        this._settings = null;
        this._coordinates = null;
        this._data = null;
        this._schedule = null;
        this._light = null;
    }
}
