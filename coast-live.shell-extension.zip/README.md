# Coast Live 4.0

Coast Live is an animated pixel-art wallpaper for GNOME Shell and Android with four selectable scenes. The sun, moon and sky lighting use a library of 2,000 Full HD images. Clouds, waves and grass animate independently and take their colors from the current sky.

![Coast, Golden Dunes, Sandstone Plateau, and Desert Oasis](preview.jpg)

## Install

Coast Live 4.0 targets GNOME Shell 45–50. Download `coast-live.shell-extension.zip` from the release and save it in Downloads. Run the following as your desktop user.

```sh
gnome-shell --version
gnome-extensions install ~/Downloads/coast-live.shell-extension.zip
```

Log out of GNOME and sign back in, then enable the extension. If the `coast-live@coastlive` extension is already installed, use `gnome-extensions install --force ~/Downloads/coast-live.shell-extension.zip` to upgrade it before signing out.

```sh
gnome-extensions enable coast-live@coastlive
gnome-extensions info coast-live@coastlive
```

The extension is running when its state is `ACTIVE`. It starts at subsequent sign-ins. Open a clear view of the desktop to see the motion.

### Upgrade from the original extension ID

Coast Live uses the extension ID `coast-live@coastlive`. Disable the old extension, then install the new ZIP using the installation steps above. Log out and back in before enabling the new ID.

```sh
gnome-extensions disable amman-coast-live@marwan
```

After the new release is running, remove the old extension if you no longer use it.

```sh
gnome-extensions uninstall amman-coast-live@marwan
```

If the original Python wallpaper timer is running, turn it off after Coast Live is visible.

```sh
systemctl --user disable --now wallpaper-selector.timer
```

## Install on Android

Coast Live 2.0 supports Android 7.0 or newer on devices that support live wallpapers. Download and install `coast-live.apk`, open **Coast Live**, select a scene, and tap **Set wallpaper** in Android’s preview. To switch scenes, reopen the app and choose again. The APK uses your device’s time zone, plays 30 FPS portrait and landscape animations, and works offline.

## Scenes

| Scene | Animated details |
| --- | --- |
| Coast | Cloud drift, waves, and swaying grass |
| Golden Dunes | Cloud drift and windblown sand |
| Sandstone Plateau | Cloud drift, dust, and swaying dry grass |
| Desert Oasis | Cloud drift, swaying palms and reeds, and water reflections |

The GNOME extension uses the local solar clock and 2,000 sky frames for every scene. Open its preferences and select **Scene → Wallpaper**. Each scene has a matching still for GNOME Appearance. Android uses ten local-time stages per scene in both orientations.

## Location and animation

The extension reads the system time zone and uses the representative location from the IANA time-zone database. For example, `Asia/Shanghai` uses Shanghai, even if you are elsewhere in China. For accurate timing in another city within the zone, enter its latitude and longitude. Change the computer’s time zone in GNOME **Settings → Date & Time** when you travel.

```sh
gnome-extensions prefs coast-live@coastlive
```

Under **Solar location**, switch on **Use custom coordinates**. Beijing, for example, is approximately `39.90` latitude and `116.41` longitude. Use negative numbers for south or west. The settings show which location is currently in use. When a zone has no representative city, the extension estimates longitude from the clock offset. The animation and solar calculations run offline.

Under **Appearance**, **Match GNOME background** uses a Coast Live still for the GNOME Appearance preview and Activities overview. The still refreshes at most once per minute. Coast Live restores the previous wallpaper on disable when its own image is still selected. A wallpaper selected manually takes priority.

Under **Animation**, choose Economy (8 FPS), Balanced (15 FPS), Smooth (25 FPS), or Ultra (50 FPS). Balanced is the default. The frame rate changes how often the moving layers are redrawn. The sky still follows local sunlight. The sun and moon paths are artistic, and polar day and night use special lighting sequences.

## Disable, uninstall, or troubleshoot

```sh
gnome-extensions disable coast-live@coastlive
gnome-extensions uninstall coast-live@coastlive
```

If the install command succeeds but the extension is missing from the list, sign out of GNOME and sign back in. If GNOME reports an error loading the extension, get its state and look for the error in the current boot’s journal.

```sh
gnome-extensions info coast-live@coastlive
journalctl --user -b _COMM=gnome-shell -g 'Coast Live|amman-coast-live' --no-pager
```

## Maintain and build a release

The install ZIP contains the readable source, preferences, schema, time-zone data, and wallpaper assets. Extract it into a project directory to work on the source.

| File | Purpose |
| --- | --- |
| `extension.js` | Mounts the desktop actors and controls the animation and lighting clocks |
| `background-sync.js` | Updates and restores the native GNOME background |
| `scene.js` | Draws and colors the coastal layers |
| `desert.js`, `themes/` | Sahara scene artwork, lighting and motion |
| `solar-clock.js` | Estimates solar altitude, sunrise, sunset, and twilight |
| `location.js`, `zone-data.js` | Selects the representative location or custom coordinates |
| `prefs.js`, `schemas/` | GNOME preferences and persistent settings |
| `solar/`, `scene-data.json` | Full HD sky images and synchronized lighting data |

From the project directory, compile the schema and package the extension. This requires `glib-compile-schemas` and `zip`.

```sh
glib-compile-schemas --strict schemas
zip -r ../coast-live.shell-extension.zip \
    metadata.json extension.js prefs.js scene.js solar-clock.js location.js zone-data.js background-sync.js desert.js \
    schemas data solar themes scene-data.json tools README.md COPYING preview.jpg
```

Use the packaged ZIP for local installation tests. Check that automatic location, custom coordinates, all frame rates, Appearance and Activities, monitor changes, disable and re-enable, and desktop sign-in work on the GNOME releases you list as supported.

### Regenerate the artwork

The release includes the rendered artwork. To regenerate it from source, install Node.js and FFmpeg, then run these commands from the project directory.

```sh
mkdir -p solar
node tools/render-art.cjs scene-data.json | ffmpeg -y -f rawvideo \
    -pix_fmt rgb24 -video_size 960x540 -framerate 30 -i pipe:0 \
    -vf scale=1920:1080:flags=neighbor -c:v mjpeg -pix_fmt yuvj444p \
    -q:v 5 -start_number 0 solar/frame_%04d.jpg
```

To rebuild the Sahara terrain and stills after regenerating the sky frames, run the following with Python, Pillow, NumPy, and SciPy installed.

```sh
python3 tools/build-sahara.py themes/source/dunes.png themes/source/plateau.png themes/source/oasis.png
```

### Publish a release

For a GitHub release, put the project files and this README in a repository, create a release tagged `v4.0.0`, and attach `coast-live.shell-extension.zip` for GNOME and `coast-live.apk` for Android. Point users to the installation steps above. You can also attach `preview.jpg` as a screenshot.

Suggested release description

> Coast Live brings a pixel-art coast and three Sahara scenes to GNOME and Android. The sky follows local daylight. GNOME offers custom coordinates and four frame rates. Android includes 30 FPS portrait and landscape animation.

For the official GNOME Extensions directory, review and test the extension against its submission guidelines. Add your public source or support URL to `metadata.json` and list the GNOME versions you have tested. The directory expects maintainers to understand and maintain the code and applies its own review policy to AI-generated code. For that submission, package the runtime files, schema XML, artwork and license. Keep the Node.js artwork generator in the public source repository.

- GitHub release instructions — https://docs.github.com/en/repositories/releasing-projects-on-github/managing-releases-in-a-repository
- GNOME Shell Extensions review guidelines — https://gjs.guide/extensions/review-guidelines/review-guidelines.html
- GNOME Shell Extensions submission — https://extensions.gnome.org/upload/

## Licensing and credits

The extension JavaScript is provided under GPL-2.0-or-later. See `COPYING`. The bundled time-zone locations and aliases come from the public-domain IANA time-zone database. The solar approximation uses NOAA’s published solar equations.

The coastal wallpaper frames and cloud masks are generated from the procedural artwork in `tools/render-art.cjs`. The Sahara scenery uses the original concept artwork in `themes/source/`, with layers prepared by `tools/build-sahara.py`. The bundled artwork is distributed under GPL-2.0-or-later with the extension.

- Time-zone data — https://www.iana.org/time-zones
- Solar equations — https://gml.noaa.gov/grad/solcalc/solareqns.PDF
